/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package deepspace;

import java.util.ArrayList;

/**
 *
 * @author laura
 */
abstract public class Damage {      // terminada
    private int nShields;
    
    Damage (int s) {
        this.nShields = s;
    }
    
    // nuevo "constructor de copia"
    abstract public Damage copy();
    
    abstract DamageToUI getUIversion();
    
    abstract public Damage adjust(ArrayList<Weapon> w, ArrayList<ShieldBooster> s);

    abstract public void discardWeapon(Weapon w);
    
    public void discardShieldBooster() { 
        if (getNShields() > 0)
            this.nShields --;
    }
    
    abstract public boolean hasNoEffect();
    
    public int getNShields() {
        return this.nShields;
    }
    
    public String toString() {
        return ("numero shields: " + nShields + "\n");
    }
}