/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package deepspace;

import java.util.ArrayList;

/**
 *
 * @author laura
 */
public class TestP1 {
    
    public static void main(String[] args) {												
       /*
        System.out.println(d2.toString());
        d2.discardWeapon(we4);
        System.out.println(d2.toString());

        System.out.println(d2.hasNoEffect());
       */
    }
}
