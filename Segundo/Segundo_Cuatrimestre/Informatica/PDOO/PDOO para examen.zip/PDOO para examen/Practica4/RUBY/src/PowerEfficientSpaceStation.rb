#encoding:utf-8

require_relative 'SpaceStation'
require_relative 'CardDealer'

module Deepspace
  
class PowerEfficientSpaceStation < SpaceStation		#terminada
	
	@@EFFIENCYFACTOR = 1.0
	
	def initialize (station) #station es SpaceStation
		super(station.name, SuppliesPackage.new(station.ammoPower, station.fuelUnits, station.shieldPower))
		copy(station)
	end
  
	#override
	def fire
		return super*@@EFFIENCYFACTOR
	end
	
	#override
	def protection
		return super*@@EFFIENCYFACTOR
	end
	
	#Override
	def setLoot(loot)
		transf = super
		if (transf == Transformation::SPACECITY)
			transf = Transformation::NOTRANSFORM
		end
		return transf
	end		#devuelve elemento de tipo Transformation
  
	def getUIversion
		PowerEfficientSpaceStation.new(self)
	end
	
	#Override
	def to_s
		out = super
		out += " (ESTACIÓN EFICIENTE)"
		return out
	end

end # class
	
end # module

