require_relative 'DamageToUI'
require_relative 'WeaponType'
require_relative 'Weapon'
require_relative 'ShieldBooster'


module Deepspace
	class Damage	#terminada
			
		private_class_method :new
		
		def initialize(s)  # s int es numero de escudos
			@nShields = s
		end
		
		attr_reader :nShields
		
		def discardShieldBooster()
					
			if @nShields > 0
				@nShields -= 1				
			end              # es void()	
		end
		
		def to_s
			out="Damage - nShields: #{@nShields}"
			return out
		end


	end
	
end			

