/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import View.DeepSpaceView;
import deepspace.CombatResult;
import static deepspace.CombatResult.ENEMYWINS;
import static deepspace.CombatResult.NOCOMBAT;
import static deepspace.CombatResult.STATIONESCAPES;
import static deepspace.CombatResult.STATIONWINS;
import static deepspace.CombatResult.STATIONWINSANDCONVERTS;
import deepspace.GameState;
import deepspace.GameUniverse;
import deepspace.GameUniverseToUI;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author laura
 */
public class ControllerExamen {
    private static final ControllerExamen instance = new ControllerExamen();
    
    public static final int WEAPON = 0x1;
    public static final int SHIELD = 0x2;
    public static final int HANGAR = 0x4;
    private GameUniverse game;
    private DeepSpaceView view;
    
    private ControllerExamen () {}
    
    public static ControllerExamen getInstance () {
      return instance;
    }
    
    public void setModelView (GameUniverse aGame, DeepSpaceView aView) {
      game = aGame;
      view = aView;
    }
    
    public void start() {
        view.updateView();
        view.showView();
    }
    
    public void finish (int i) {
        if (view.confirmExitMessage()) {
          System.exit(i);
        }
    }
      

    public GameState getState() {
      return game.getState();
    }
    
    public GameUniverseToUI getUIversion() {
      return game.getUIversion();
    }
    
    private void invertArray (ArrayList<Integer> array) {
      int i, n;
      
      n = array.size();
      for (i = 0; i < n/2; i++)
        Collections.swap(array, i, n-i-1);
    }
    
    public void mount (ArrayList<Integer> weapons, ArrayList<Integer> shields) {
      invertArray (weapons);
      invertArray (shields);
      
      for (int i : weapons) {
        game.mountWeapon(i);
      }
      for (int i : shields) {
        game.mountShieldBooster(i);
      }
    }
    
    public void discard (int places, ArrayList<Integer> weapons, ArrayList<Integer> shields) {
      invertArray(weapons);
      invertArray(shields);
      
      if ((places & WEAPON) == WEAPON) {
        for (int i : weapons) {
          game.discardWeapon(i);
        }
      } else if ((places & SHIELD) == SHIELD) {
        for (int i : shields) {
          game.discardShieldBooster(i);
        }
      } else if((places & HANGAR) == HANGAR) {
        for (int i : weapons) {
          game.discardWeaponInHangar(i);
        }
        for (int i : shields) {
          game.discardShieldBoosterInHangar(i);
        }
      }
    }
    
    public void discardHangar () {
        game.discardHangar();
    }
}
