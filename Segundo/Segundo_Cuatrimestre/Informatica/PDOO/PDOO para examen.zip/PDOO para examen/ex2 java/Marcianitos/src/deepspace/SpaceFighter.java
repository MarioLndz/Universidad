/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package deepspace;

/**
 *
 * @author laura
 */
public interface SpaceFighter {  // para enemystarship y spacestation
    
    public float fire();
    
    public float protection();
    
    public ShotResult receiveShot(float shot);
}
