/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main;

import View.DeepSpaceView;
import View.GUI.MainWindowExamen;
import controller.Controller;
import deepspace.GameUniverse;

/**
 *
 * @author laura
 */
public class ExamenP5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MainWindowExamen ui;
        //GameUniverse game = new GameUniverse();
        ui = MainWindowExamen.getInstance();
        Controller controller = Controller.getInstance();
        controller.setModelView(game,ui);
        controller.start();  
    }
    
}
