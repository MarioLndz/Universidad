#encoding: UTF-8

module Deepspace
	module WeaponType
		class Type
			def initialize (p) # p es float
				@power = p
			end
			
			attr_reader	:power
			
			def to_s
				if (self == WeaponType::LASER)
					type = "LASER"
				elsif (self == WeaponType::MISSILE)
						type = "MISSILE"
				elsif (self == WeaponType::PLASMA)
						type = "PLASMA"
				elsif (self == WeaponType::ACIDO)
						type = "ACIDO"
				elsif (self == WeaponType::ROCA)
						type = "ROCA"
				elsif (self == WeaponType::ASTEROIDE)
						type = "ASTEROIDE"
				end
				
				return type
			end
		end
		
		LASER = Type.new(2.0)
		MISSILE = Type.new(3.0)
		PLASMA = Type.new(4.0)
		ACIDO = Type.new(5.0)
		ROCA = 	Type.new(1.0)
		ASTEROIDE = Type.new(7.0)
		
	end

end
