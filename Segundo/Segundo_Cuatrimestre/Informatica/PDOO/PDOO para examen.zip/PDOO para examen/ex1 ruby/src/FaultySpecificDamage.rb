
require_relative 'SpecificDamage'
require_relative 'Dice'

module Deepspace

class FaultySpecificDamage < SpecificDamage	
	
	#se puede omitir?
	def initialize (wl,s)   #wl es array de weapontype, s int es numero de escudos
		super(wl,s)
	end
    
	@override
	def adjust(w,s)   # w es un array list de Weapon, s es un Array list de shield
		
		#newDamage = super(w,s) ns como reutilizar el otro
		
		l_nshields = [s.length, nShields].min
		result = []
		w_aux = w.clone
			
		@weapons.each do |element|
			indice = arrayContainsType(w_aux, element)
	  
			if indice != -1
				result.push(element)
				w_aux.delete_at(indice)
			end
		end
		
		d=Dice.new
		wt = d.loseExtraWeapon
		
		if (wt != nil)
			j = arrayContainsType(result, wt)
			if j != -1
				result.delete_at(j)
			end
		end
		
		return FaultySpecificDamage.new(result, l_nshields)    # Damage ajustado a lo que hemos pasado
	end
	
end # class

end # module

