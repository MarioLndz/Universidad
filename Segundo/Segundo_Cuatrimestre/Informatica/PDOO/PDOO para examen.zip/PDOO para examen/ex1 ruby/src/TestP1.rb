#encoding: UTF-8

require_relative 'SpaceStation'
require_relative 'FaultySpecificDamage'
require_relative 'NumericDamage'

module Deepspace
	
	wR = Weapon.new("roca",WeaponType::ROCA, 3)
	wAst = Weapon.new("asteroide",WeaponType::ASTEROIDE, 3)
	wAc = Weapon.new("acido",WeaponType::ACIDO, 3)

	wl = [WeaponType::ROCA,WeaponType::ASTEROIDE,WeaponType::ACIDO,WeaponType::ROCA]
	
	s = ShieldBooster.new("s",4,2)

	fDam = FaultySpecificDamage.new(wl,10)

	puts fDam.to_s + "\n"
	
	sup = SuppliesPackage.new(3,5,1)
	st = SpaceStation.new("st",sup)
	st.receiveHangar(Hangar.new(5))
	st.receiveWeapon(wAc)
	st.receiveWeapon(wR)
	st.receiveWeapon(wAc)
	st.receiveShieldBooster(s)
	for i in (0..2)
		st.mountWeapon(0)
	end
	st.mountShieldBooster(0)
	
	puts st.to_s

	st.setPendingDamage(fDam)

	puts st.to_s
end
