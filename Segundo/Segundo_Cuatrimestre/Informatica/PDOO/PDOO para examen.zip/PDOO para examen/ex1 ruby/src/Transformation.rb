
module Deepspace
	module Transformation
		NOTRANSFORM=	:notransform
		GETEFFICIENT=	:getefficient
		SPACECITY=		:spacecity
	end

end
