/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main;

import View.GUI.MainWindowExamen;
import controller.Controller;
import deepspace.GameUniverse;

/**
 *
 * @author laura
 */
public class MainExamen {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MainWindowExamen ui = MainWindowExamen.getInstance();
        Controller controller = Controller.getInstance();
        GameUniverse game = new GameUniverse();
        controller.setModelView(game, ui);
        controller.start();
    }
    
}
