
package View.GUI;

/**
 * @brief Interfaz utilizada por WeaponView y por ShieldView
 */
interface CombatElementView {
    public boolean isSelected();
}
