package deepspace;

import java.util.ArrayList;

/**
 *
 * @author laura
 */
public class SpecificDamage extends Damage{     // terminada
    private ArrayList<WeaponType> weapons; 
    
    SpecificDamage(ArrayList<WeaponType> wl, int s) {
        super(s);
        if (wl != null)
            this.weapons = wl;
        else
            this.weapons = new ArrayList<>();
    }
    
    private int arrayContainsType(ArrayList<Weapon> w, WeaponType t) {        
        int pos = -1;
        boolean encontrado = false;
        int i = 0;
        
        while(i<w.size() && !encontrado) {
            if (w.get(i).getType() == t) {
                encontrado = true;
                pos = i;
            }
            else
                i++;
        }
        
        return pos;
    }
    
    // "constructor de copia"
    @Override
    public SpecificDamage copy() {     // ns si esta bien
        return (new SpecificDamage(this.getWeapons(), this.getNShields()));
    }
    
    @Override
    SpecificDamageToUI getUIversion(){
        return new SpecificDamageToUI(this);
    }
    
    @Override
    public SpecificDamage adjust(ArrayList<Weapon> w, ArrayList<ShieldBooster> s) {
        
        int l_nshields = Math.min(s.size(), this.getNShields());

        ArrayList<WeaponType> result = new ArrayList<>();
        ArrayList<Weapon> aux = new ArrayList<>(w);

        for (int i = 0; i<this.getWeapons().size(); i++) {
            WeaponType element = this.getWeapons().get(i);
            int indice = this.arrayContainsType(aux, element);
            if (indice != -1) {
                result.add(element);
                aux.remove(indice);
            }
        }                    

        return new SpecificDamage(result, l_nshields);
    }
    
    @Override
    public void discardWeapon(Weapon w) {
        if (getWeapons() != null) 
            getWeapons().remove(w.getType());
    }

    @Override
    public boolean hasNoEffect(){ 
        boolean retorno;
        if (this.getWeapons() != null)
            retorno = (this.getWeapons().isEmpty() && this.getNShields()==0);
        else
            retorno = this.getNShields()==0;
        
        return retorno;
    }
    
    public ArrayList<WeaponType> getWeapons(){
        return this.weapons;
    }
    
    @Override
    public String toString() {
        
        String out = super.toString();
        
        if (getWeapons() != null) 
            out += getWeapons().toString();
        
        return out;
    }
}