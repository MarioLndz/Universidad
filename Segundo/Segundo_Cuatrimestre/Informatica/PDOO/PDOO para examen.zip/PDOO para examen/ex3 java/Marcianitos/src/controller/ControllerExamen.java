/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import View.DeepSpaceView;
import View.GUI.MainWindowExamen;
import deepspace.GameUniverse;
import deepspace.GameUniverseToUI;

/**
 *
 * @author laura
 */
public class ControllerExamen { // no se usa
    private static final ControllerExamen instance = new ControllerExamen();
    private GameUniverse game;
    private MainWindowExamen view;
    
    private ControllerExamen () {}
    
    public static ControllerExamen getInstance () {
      return instance;
    }
    
    public void setModelView (GameUniverse aGame, MainWindowExamen aView) {
      game = aGame;
      view = aView;
    }
    
    public void start() {
        view.updateView();
        view.showView();
    }
    
    public void nextEnemy() {
        game.nextEnemy();
        
    }
    
    public GameUniverseToUI getUIversion() {
      return game.getUIversion();
    }
}
