/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package deepspace;

/**
 *
 * @author mario
 */
public class BetaPowerEfficientSpaceStation extends PowerEfficientSpaceStation{
    
    private static final float EFFIENCYFACTOR=1.2f;
    private Dice dice;
    
    BetaPowerEfficientSpaceStation(SpaceStation station){
        super(station);
    }

    float fire(){
        
        
    }
    
}
