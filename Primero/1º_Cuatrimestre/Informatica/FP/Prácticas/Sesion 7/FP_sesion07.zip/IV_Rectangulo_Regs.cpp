/*****************************************************************************
	Mario L�ndez Mart�nez
	Grupo: A2

	Ejercicio 4 - IV: Este programa leer� las coordenadas que definen un 
	rect�ngulo y calcular� la circunferencia centrada en el punto de corte de 
	las diagonales del rect�ngulo tal que su superficie sea la menor entre 
	todas las circunferencias de �rea mayor que la del rect�ngulo.

*****************************************************************************/
#include <iostream>
#include <string>
#include <cmath>

using namespace std; 

struct Punto2D {
	double x;
	double y;
};

struct Rectangulo {
	Punto2D superior_izquierda;
	Punto2D inferior_derecha;
};

struct Circunferencia { 
	Punto2D centro; 
	double radio; 
};

/*****************************************************************************
//	PuntoCorteDiagonales

	Funci�n que calcula el punto donde se cortan las diagonales del rect�ngulo

	RECIBE: Coordenadas de la esquina superior izquierda y la inferior 
			derecha.
	DEVUELVE: Punto de las diagonales del rect�ngulo.
	PRE: El rect�ngulo debe estar bien definido
*****************************************************************************/
Punto2D PuntoCorteDiagonales(Rectangulo rectangulo){
	
	Punto2D punto_corte;
	
	punto_corte.x = (rectangulo.inferior_derecha.x - 
					rectangulo.superior_izquierda.x) / 2 + 
					rectangulo.superior_izquierda.x;
	
	punto_corte.y = (rectangulo.inferior_derecha.y - 
					rectangulo.superior_izquierda.y) / 2 + 
					rectangulo.superior_izquierda.y;	
	
	return punto_corte;
}

/***************************************************************************
//	AreaRectangulo
	
	Funci�n que calcula el valor del �rea del rect�ngulo
	
	RECIBE: Las coordenadas de la esquina superior izquierda y la inferior
			derecha.
	DEVUELVE: El �rea del rect�ngulo.
	PRE: El rect�ngulo debe estar bien definido
***************************************************************************/
double AreaRectangulo(Rectangulo rectangulo){
	
	double area = fabs(rectangulo.superior_izquierda.x - 
				  rectangulo.inferior_derecha.x) * fabs
				  (rectangulo.superior_izquierda.y - 
				  rectangulo.inferior_derecha.y);
				
	return area;
}

/***************************************************************************
//	AreaCircunferencia

	Funci�n que calcula el valor del �rea de la circunferencia
	
	RECIBE: Radio de la circunferencia.
	DEVUELVE: �rea de la circunferencia.
	PRE: La circunferencia debe estar bien definida (radio > 0)
***************************************************************************/
double AreaCircunferencia(Circunferencia circunferencia){
	
	const double PI = 3.1416;
	double area;
	
	area = PI * pow(circunferencia.radio, 2);
	
	return area;
}

/***************************************************************************/
int main () {
	//Constantes
	const double RADIO_INICIO = 0.5;
	const double SALTO_DE_RADIO = 0.25;
	
	//Variables
	Rectangulo rectangulo;
	double area_rectangulo;
	
	Circunferencia circunferencia;
	double radio, area_circunferencia; 
	
	//ENTRADA
	cout << "Coordenadas de la esquina superior izquierda:" << endl;
	cout << "\t" << "x = ";
	cin >> rectangulo.superior_izquierda.x;
	
	cout << "\t" << "y = ";
	cin >> rectangulo.superior_izquierda.y;
	
	//El punto que define la esquina inferior derecha del rect�ngulo no puede
	//estar ni por encima ni a la izquierda del punto que define la esquina
	//superior izquierda. Con esto nos aseguramos de que el rect�ngulo est�
	//bien definido
	cout << "Coordenadas de la esquina inferior derecha:" << endl;
	do {
		cout << "\t" << "x = ";	
		cin >> rectangulo.inferior_derecha.x;
		
	} while (rectangulo.inferior_derecha.x <= rectangulo.superior_izquierda.x);
	
	do {
		cout << "\t" << "y = ";
		cin >> rectangulo.inferior_derecha.y;
		
	} while (rectangulo.inferior_derecha.y >= rectangulo.superior_izquierda.y);
	
	//C�LCULOS
	radio = RADIO_INICIO;
	area_circunferencia = 0;

	area_rectangulo = AreaRectangulo(rectangulo);
	circunferencia.centro = PuntoCorteDiagonales(rectangulo);
	
	while(area_circunferencia <= area_rectangulo){
		circunferencia.radio = radio;
		area_circunferencia = AreaCircunferencia(circunferencia);
		
		radio += SALTO_DE_RADIO;
	}
	
	//SALIDA DE DATOS
	cout << endl;
	cout << "Rect�ngulo: " << endl;
	//Coordenadas de los puntos que definen al rect�ngulo
	cout << "\t" << "Esquina superior izquierda = (" 
		 << rectangulo.superior_izquierda.x << ", " 
		 << rectangulo.superior_izquierda.y << ")" << endl;
	
	cout << "\t" << "Esquina inferior derecha = (" 
		 << rectangulo.inferior_derecha.x << ", " 
		 << rectangulo.inferior_derecha.y << ")" << endl;
		 
	//�rea del rectangulo
	cout << "\t" << "Area del rectangulo: " << area_rectangulo << endl;
	
	cout << endl;
	cout << "Circunferencia:" << endl;
	
	//Centro de la circunferencia
	cout << "\t" << "Centro = (" << circunferencia.centro.x << ", " 
		 << circunferencia.centro.y << ")" << endl;
	
	//Radio y �rea de la circunferencia
	cout << "\t" << "Radio = " << circunferencia.radio << endl;
	cout << "\t" << "�rea = " << area_circunferencia << endl;

	return 0;
}
