/*****************************************************************************
	Mario L�ndez Mart�nez
	Grupo: A2

	Ejercicio 19 - III: Este programa servir� para comprobar el funcionamiento
	de una funci�n que leer� y devolver� un dato double.

*****************************************************************************/

#include <iostream>   // Inclusi�n de los recursos de E/S
#include <string>

using namespace std;

/*****************************************************************************
//	EsDigito

	Se comprobar� si el string indicado est� formado s�lo por d�gitos
	
	RECIBE: String a comprobar
	DEVUELVE: Verdadero o Falso
*****************************************************************************/
bool EsDigito (string cadena){
	bool es_digito = true;
	
	int longitud = cadena.length();
	
	//Primero comprobaremos que la cadena no est� vac�a o que solo est� formada
	//por la coma decimal
	if (cadena == "." || cadena == ""){
		es_digito = false;
	} else {
		int n = 0;
		
		//Comprueba que toda la cadena est� formada por d�gitos (con decimales)
		//si la cadena empieza con un signo, pasar� al siguiente caracter
		if (cadena[0] == '-' || cadena[0] == '+'){
			n++;
		}
		for (; n < longitud && es_digito; n++){
			if ((cadena[n] < '0' || cadena[n] > '9') && (cadena[n] != '.')){
				es_digito = false;
			}
		}
	}
	return es_digito;
}

/*****************************************************************************
//	LeeReal

	Se leer� y devolver� un dato double. Si el valor leido no 
	fuera un double, la funci�n volver� a pedirlo hasta que se proporcione un 
	valor correcto.
	
	RECIBE: T�tulo
	DEVUELVE: N�mero real (double)
******************************************************************************/
double LeeReal (string titulo){
	string num_introducido;
	bool no_caracter;
	
	double numero;
	
	do {
		cout << titulo;
		getline (cin, num_introducido);
		
		no_caracter = EsDigito (num_introducido);
		
		//Si la cadena est� formada por d�gitos (no posee ning�n caracter), la
		//transformamos
		if (no_caracter){
			numero = stod(num_introducido);
		}
		
	} while (!no_caracter);

	return numero;
}

/*****************************************************************************/
int main () {
	//Variables
	double num_real;
	
	//Entrada de datos
	num_real = LeeReal("Introduzca un n�mero entero: ");
	cout << endl;
		
	//Salida de datos
	cout << "1) N�mero real = " << num_real << endl;
	
	return 0;
}
